﻿using System;

namespace Framework_App_4_8
{
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// The main method that is executed when the application starts.
        /// </summary>
        /// <param name="args">An array of command-line arguments.</param>
        static void Main(string[] args)
        {
            int test = Int32.MaxValue;

            Console.WriteLine("another");
        }
    }

}
