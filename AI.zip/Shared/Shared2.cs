﻿namespace Core_Lib_net7.Shared;

public class Shared2
{
    
}